//
//  ViewController.swift
//  my_calculator
//
//  Created by 梁志榆 on 2022/5/4.
//

import UIKit


class ViewController: UIViewController {
    
    @IBOutlet weak var result: UILabel!
    
    
    @IBOutlet weak var operaters: UILabel!
    
    
    var numm=1
    var operater_list=["*","/","+","-"]
    var num_list=["1","2","3","4","5","6","7","8"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func unmbers(_ sender: UIButton) {
        ACtoC()
        clearHighlight()
        if operaters.text?.suffix(1) != "0"  {
            operaters.text=operaters.text!+sender.currentTitle!}
        else{
            if operaters.text?.suffix(2) == "/0" || operaters.text?.suffix(2) == "*0" || operaters.text?.suffix(2) == "+0" || operaters.text?.suffix(2) == "-0" || operaters.text == "0"{
                operaters.text?.removeLast()}
            operaters.text=operaters.text!+sender.currentTitle!
            
            
        }
    }
    
    @IBAction func operater(_ sender: UIButton) {
        if  operaters.text == ""{}
        else if operaters.text?.suffix(1) != "/" && operaters.text?.suffix(1) != "*" && operaters.text?.suffix(1) != "+" &&
            operaters.text?.suffix(1) != "-"{
        if sender.currentTitle=="÷"{
            operaters.text=operaters.text!+"/"
            Highlight()
        }
        else if sender.currentTitle=="x"{
            operaters.text=operaters.text!+"*"
            Highlight()
        }
        else{
            operaters.text=operaters.text!+sender.currentTitle!
            Highlight()
        }}
        else if (operaters.text?.suffix(1)=="*" && sender.currentTitle=="÷")||(operaters.text?.suffix(1)=="/" && sender.currentTitle=="x"){
            operaters.text?.removeLast()
            if sender.currentTitle=="÷"{
                operaters.text=operaters.text!+"/"
                Highlight()
            }
            else if sender.currentTitle=="x"{
                operaters.text=operaters.text!+"*"
                Highlight()
            }
            else{
                operaters.text=operaters.text!+sender.currentTitle!
                Highlight()
            }
            
        }
        else{
            if sender.currentTitle=="÷"{
                operaters.text=operaters.text!+"/"
                Highlight()
            }
            else if sender.currentTitle=="x"{
                operaters.text=operaters.text!+"*"
                Highlight()
            }
            else{
                operaters.text=operaters.text!+sender.currentTitle!
                Highlight()
            }
            
        }
        CtoAC()
        
        }// end of operater
    
    @IBAction func the_zero(_ sender: UIButton) {
        ACtoC()
        if operaters.text?.suffix(1) == "0" {
            if operaters.text?.suffix(2) == "/0" || operaters.text?.suffix(2) == "*0" || operaters.text?.suffix(2) == "+0" || operaters.text?.suffix(2) == "-0" || operaters.text=="0"{
                
            }
            else{operaters.text=operaters.text!+sender.currentTitle!}
            
        }
        else{
            operaters.text=operaters.text!+sender.currentTitle!
        }
    }// end of the zero
    
    @IBAction func dot(_ sender: UIButton) {
        ACtoC()
        if operaters.text?.suffix(1) == "/" || operaters.text?.suffix(1) == "*" || operaters.text?.suffix(1) == "+" ||
            operaters.text?.suffix(1) == "-" ||
        operaters.text=="" ||
            operaters.text?.suffix(1)=="."{
            
        }
        else{
            operaters.text=operaters.text!+sender.currentTitle!
        }}// end of dot
    
    @IBAction func resset(_ sender: UIButton) {
        if sender.currentTitle=="C"{
            result.text="0"
            if operaters.text != ""{
                operaters.text?.removeLast()}
            if operaters.text?.suffix(1) != "+" && operaters.text?.suffix(1) != "-" && operaters.text?.suffix(1) != "*" && operaters.text?.suffix(1) != "/"{
                clearHighlight()
            }
            else{Highlight()}
        }
        else if sender.currentTitle=="AC"{
            sender.setTitle("C", for: .normal)
            result.text="0"
            operaters.text=""
            clearHighlight()
            
            
        }
    }// end of reset
    
    @IBAction func equal(_ sender: UIButton) {
        if operaters.text?.suffix(1) != "/" && operaters.text?.suffix(1) != "*" && operaters.text?.suffix(1) != "+" &&
            operaters.text?.suffix(1) != "-"{
            let _operation = operaters.text!
            let expression = NSExpression(format: _operation)
            let value = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as! Double
            let answer = Float(value)
            result.text = answer.trimAndStringify
            if result.text=="inf"{
                result.text="0"
            }
            CtoAC()
            
        }} // end of equal
    
    
    @IBAction func minus_and_plus(_ sender: Any) {
        if operaters.text?.prefix(1)=="-"{
            operaters.text?.removeFirst()
            if operaters.text?.prefix(1)=="("{
                operaters.text?.removeFirst()
                operaters.text?.removeLast()
            }
        }
        else{
            operaters.text="-("+operaters.text!+")"
        }
            
            
            
            
        }
        
        
        
        
    
    
    
    @IBAction func percentage(_ sender: Any) {
        if operaters.text?.suffix(1) != "/" && operaters.text?.suffix(1) != "*" && operaters.text?.suffix(1) != "+" &&
            operaters.text?.suffix(1) != "-"{
            operaters.text=operaters.text!+"/100"
        }
    }
    func CtoAC(){
        for case let button as UIButton in self.view.subviews {
            if button.currentTitle == "C"{
                button.setTitle("AC", for: .normal)
            }
        }
    }
    
    func ACtoC(){
        for case let button as UIButton in self.view.subviews {
            if button.currentTitle == "AC"{
                button.setTitle("C", for: .normal)
            }
        }
    }
    func clearHighlight(){
        for case let button as UIButton in self.view.subviews {
            if button.backgroundColor == UIColor.white{
                button.backgroundColor = UIColor.orange
                button.setTitleColor(UIColor.white, for: .normal)
        }
    }
    }
    func Highlight(){
        let last = self.operaters.text?.suffix(1)
        switch(last){
        case "+":
            for case let button as UIButton in self.view.subviews {
                if button.currentTitle == "+"{
                    button.backgroundColor = UIColor.white
                    button.setTitleColor(UIColor.orange, for: .normal)
                }
            }
        case "-":
            for case let button as UIButton in self.view.subviews {
                if button.currentTitle == "-"{
                    button.backgroundColor = UIColor.white
                    button.setTitleColor(UIColor.orange, for: .normal)
                }
            }
        case "*":
            for case let button as UIButton in self.view.subviews {
                if button.currentTitle == "x"{
                    button.backgroundColor = UIColor.white
                    button.setTitleColor(UIColor.orange, for: .normal)
                }
            }
        case "/":
            for case let button as UIButton in self.view.subviews {
                if button.currentTitle == "÷"{
                    button.backgroundColor = UIColor.white
                    button.setTitleColor(UIColor.orange, for: .normal)
                }
            }
        default:
            for case let button as UIButton in self.view.subviews {
                if operater_list.contains(button.currentTitle!){
                    button.backgroundColor = UIColor.orange
                }
            }
        }

    }
}
    
    


